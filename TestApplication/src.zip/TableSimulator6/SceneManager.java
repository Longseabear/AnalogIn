package TableSimulator6;

import java.awt.Graphics;

public class SceneManager {
	public void screenDraw(Graphics g) {
	}
	public void removeScene(){
		System.exit(0);
	}
	public static SceneManager createScene(int i, TableSimulator GameObject){
		switch(i){
		case 1:
			return new Scene1(GameObject);
		case 2:
			return new Scene2(GameObject);
		}
		return null;	
	}
}
