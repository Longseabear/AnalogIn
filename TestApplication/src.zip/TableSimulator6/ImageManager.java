package TableSimulator6;

import java.awt.Image;

import javax.swing.ImageIcon;

public class ImageManager {
	static final Image background = new ImageIcon(Main.class.getResource("../image/testBackground.jpg")).getImage();
	static final Image testButtonImage = new ImageIcon(Main.class.getResource("../image/2.png")).getImage();
}
