package TableSimulator5;

public class Main {

	public static final int SCREEN_SIZE_X = 1280;
	public static final int SCREEN_SIZE_Y = 720;
	
	public static void main(String args[])
	{
		new TableSimulator();
	}
}
