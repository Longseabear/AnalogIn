package TableSimulator6;

import java.awt.Graphics;

public class SceneManager {
	public void screenDraw(Graphics g) {
	}
}
